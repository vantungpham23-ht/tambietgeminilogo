# Gemini Watermark Remover Chrome Extension v1.0.20

## Install

1. Extract this zip file.
2. Open `chrome://extensions`.
3. Enable Developer mode.
4. Click Load unpacked.
5. Select the extracted `gemini-watermark-remover-extension` folder.

## Update

Download the new zip, replace the extracted folder, then click Reload on the extension card.

## Privacy

The extension runs on Gemini pages only. It processes generated image previews, copy actions, and download actions in the browser. It does not collect accounts, prompts, chats, or personal data. It may request Gemini and Googleusercontent image assets so the image can be processed locally.
